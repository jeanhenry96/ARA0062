<?php

include_once "../conexaoBD/Bd.php";

$id=$_GET["id"];

$sql = "delete from blog where id='$id' ";
$bd = new Bd();
$contador = $bd->exec($sql);

echo "<h1>Foi Excluído com Sucesso ( $contador ) Registro(s)</h1>";

?>

<a href="ConsultaBlog.php">Voltar</a>
