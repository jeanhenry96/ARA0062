<?php

include_once "../conexaoBD/Bd.php";

$id=$_GET["id"];
$name=$_GET["nome"];
$login=$_GET["usuario"];
$senha=$_GET["senha"];

if (isset($_GET["id"])) { //atualiza
    $id = $_GET["id"];
    $sql = "UPDATE `usuario` SET usuario_id='$id', nome='$name', usuario='$login', senha='$senha' where usuario_id='$id' ";
}else { //grava um novo
    $sql = "INSERT INTO `usuario` (`usuario_id`, `nome`, `usuario`, `senha`) VALUES (NULL, '$name', '$login', '$senha')";    
}

$bd = new Bd();
$contador = $bd->exec($sql);

echo "<h1>Foi Armazenado/Atualizado com Sucesso ( $contador ) Registro(s)</h1>";

?>

<a href="ConsultaUsuario.php">Voltar</a>