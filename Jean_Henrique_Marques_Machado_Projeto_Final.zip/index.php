<?php

include_once "conexaoBD/Bd.php";
session_start();

?>

<!doctype html>
<html>
    
    <head>
        
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Super-Heróis</title>
        <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js" crossorigin="anonymous"></script>
        <!-- Fontes Google-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700" rel="stylesheet" type="text/css" />
        <!-- Temas Css (Incluindo Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body id="page-top">
        
        <!-- Navegação-->
        <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
            <div class="container">
                <a class="navbar-brand js-scroll-trigger" href="#page-top"><img src="assets/img/navbar-logo.png" height="50" width="130" /></a>
                <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars ml-1"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav text-uppercase ml-auto">
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="menu.php" style="color: Yellow"><?php echo $_SESSION['usuario'];?></a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="areaLogin.php">Logar-se </a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#destaquedia">Destaque Diário </a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#blog">Área do Blog</a></li> 
                        
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#noticias">Notícias</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#equipe">Equipe</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#contact">Contatos</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        
        <!-- Inicio -->
        <header class="masthead">
            <div class="container">
                <div class="masthead-subheading">Conheça o mundo dos heróis!</div>
                <div class="masthead-heading text-uppercase">Prazer em vê-lo aqui !!!</div>
                <a class="btn btn-primary btn-xl text-uppercase js-scroll-trigger" href="#destaquedia">Divirta-se</a>
            </div>
        </header>
        
        <!-- Destaque Diario -->
        <section class="page-section bg-light" id="portfolio">
            <a id="destaquedia"></a>
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Destaque Diário</h2>
                    <h3 class="section-subheading text-muted">Os super-heróis são famosos desde 1938. De lá pra cá, a fama e admiração por esses personagens só aumentou. Mas, quais são os mais populares?</h3>
                    <h4 class="section-subheading text-muted"> Conheça história de alguns deles</h4>
                </div>
                <br>
                <div class="row">
                    <div class="col-lg-4 col-sm-6 mb-4">
                        <div class="portfolio-item">
                            <a class="portfolio-link" data-toggle="modal" href="#portfolioModal1">
                                <div class="portfolio-hover">
                                    <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                                </div>
                                <img class="img-fluid" src="assets/img/portfolio/01-thumbnail.jpg" alt="" />
                            </a>
                            <div class="portfolio-caption">
                                <div class="portfolio-caption-heading" style="color:Green;">Hulk</div>
                                <div class="portfolio-caption-subheading text-muted">Besta-Verde</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4 col-sm-6 mb-4">
                        <div class="portfolio-item">
                            <a class="portfolio-link" data-toggle="modal" href="#portfolioModal2">
                                <div class="portfolio-hover">
                                    <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                                </div>
                                <img class="img-fluid" src="assets/img/portfolio/02-thumbnail.jpg" alt="" />
                            </a>
                            <div class="portfolio-caption">
                                <div class="portfolio-caption-heading" style="color:Red;">Homem de Ferro</div>
                                <div class="portfolio-caption-subheading text-muted">Gênio / Bilionário</div>
                            </div>
                        </div>
                    </div>
                   
                    <div class="col-lg-4 col-sm-6 mb-4">
                        <div class="portfolio-item">
                            <a class="portfolio-link" data-toggle="modal" href="#portfolioModal3">
                                <div class="portfolio-hover">
                                    <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                                </div>
                                <img class="img-fluid" src="assets/img/portfolio/03-thumbnail.jpg" alt="" />
                            </a>
                            <div class="portfolio-caption">
                                <div class="portfolio-caption-heading" style="color:DeepPink;">Mulher Maravilha</div>
                                <div class="portfolio-caption-subheading text-muted">Linda porém violenta</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4 col-sm-6 mb-4">
                        <div class="portfolio-item">
                            <a class="portfolio-link" data-toggle="modal" href="#portfolioModal4">
                                <div class="portfolio-hover">
                                    <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                                </div>
                                <img class="img-fluid" src="assets/img/portfolio/04-thumbnail.jpg" alt="" />
                            </a>
                            <div class="portfolio-caption">
                                <div class="portfolio-caption-heading" style="color:DeepSkyBlue;">Thor</div>
                                <div class="portfolio-caption-subheading text-muted">Deus do Trovão</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4 col-sm-6 mb-4">
                        <div class="portfolio-item">
                            <a class="portfolio-link" data-toggle="modal" href="#portfolioModal5">
                                <div class="portfolio-hover">
                                    <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                                </div>
                                <img class="img-fluid" src="assets/img/portfolio/05-thumbnail.jpg" alt="" />
                            </a>
                            <div class="portfolio-caption">
                                <div class="portfolio-caption-heading" style="color:Red;">Homem Aranha</div>
                                <div class="portfolio-caption-subheading text-muted">Aranha Humana</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4 col-sm-6 mb-4">
                        <div class="portfolio-item">
                            <a class="portfolio-link" data-toggle="modal" href="#portfolioModal6">
                                <div class="portfolio-hover">
                                    <div class="portfolio-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                                </div>
                                <img class="img-fluid" src="assets/img/portfolio/06-thumbnail.jpg" alt="" />
                            </a>
                            <div class="portfolio-caption">
                                <div class="portfolio-caption-heading" style="color:Gray;">Batman</div>
                                <div class="portfolio-caption-subheading text-muted">Homem Morcego</div>
                            </div>
                        </div>
                    </div>
                </section>
        
        <!-- Area Blog -->
  <section class="page-section" id="blog">
                    <div class="container">
        
       <div class="text-center">
                    <h2 class="section-heading text-uppercase">Área do Blog</h2>
                    
                </div>
        
        <br><br>
        <div class="row">
        
        <?php
        
            include_once("conexaoBD/Bd.php");
            $bd = new Bd();
            $sql = "select * from blog";
            
            foreach ($bd->query($sql) as $row) {
               echo  '
                <div class="card mr-5 mb-5" style="width: 18rem;">
                  <div class="card-body">
                    <h5 class="card-title">'.$row['titulo'].'</h5>
                    <p class="card-text">'.substr($row['corpo'],0,200).'</p>
                  </div>
                </div>
               ';
            }
        ?>
        </div>
    </section>
        
        <!-- Noticias-->
        <section class="page-section" id="noticias">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">SUPER-HERÓIS</h2>
                    <h3 class="section-subheading text-muted">Últimas notícias de Super-Heróis.</h3>
                </div>
                <ul class="timeline">
                    <li>
                        <div class="timeline-image"><img class="rounded-circle img-fluid" src="assets/img/about/1.jpg" alt="" /></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>Outubro 2020</h4>
                                <h4 class="subheading">‘Vingadores’, da Marvel, lançam campanha em apoio a Joe Biden </h4>
                            </div>
                            <div class="timeline-body"><p class="text-muted">Parte do elenco da franquia Os Vingadores, da Marvel, acaba de reforçar o time de celebridades que apoia o candidato americano Joe Biden. Os atores vão participar de um evento virtual para levantar fundos que serão destinados à campanha do democrata, que disputa as eleições presidenciais com Donald Trump.</div>
                    </li>
                    <li class="timeline-inverted">
                        <div class="timeline-image"><img class="rounded-circle img-fluid" src="assets/img/about/2.jpg" alt="" /></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>Outubro 2020</h4>
                                <h4 class="subheading">"Homem-Aranha 3": Tom Holland e Zendaya já estão juntos para começar a gravar.</h4>
                            </div>
                            <div class="timeline-body"><p class="text-muted">Sim, as gravações de "Homem-Aranha 3" já estão prestes a começar e se você acomapanha Tom Holland e Zendaya nas redes sociais, provavelmente percebeu que os dois atores chegaram em Atlanta, nos Estados Unidos, no início desta semana e que o nosso Peter Parket até já recebeu o roteiro do novo filme. Ou seja, vem aí!</p></div>
                        </div>
                    </li>
                    <li>
                        <div class="timeline-image"><img class="rounded-circle img-fluid" src="assets/img/about/3.jpg" alt="" /></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>Setembro 2020</h4>
                                <h4 class="subheading">Lady Gaga pode interpretar Emma Frost em novo filme da Marvel, revela site americano.</h4>
                            </div>
                            <div class="timeline-body"><p class="text-muted">Parece que Lady Gaga vai atacar como atriz em breve e dessa vez numa produção da Marvel. De acordo com as informações divulgadas pelo site We Got This Covered, a dona do álbum "Chromatica" pode ser escalada para interpretar Emma Frost em uma nova produção dos "X-Men". Nem é preciso dizer que a internet está pirando com essa notícia, né?</p></div>
                        </div>
                    </li>
                    <li class="timeline-inverted">
                        <div class="timeline-image"><img class="rounded-circle img-fluid" src="assets/img/about/4.jpg" alt="" /></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>Maio 2020</h4>
                                <h4 class="subheading">Você consegue imaginar os personagens da Disney como heróis da Marvel e da DC Comics?</h4>
                            </div>
                            <div class="timeline-body"><p class="text-muted">Será que os fãs de animação pensam nos seus personagens favoritos em situações inusitadas? Afinal, estamos falando de desenhos e tudo o que conhecemos sobre eles é o que nos mostram em filmes. Ou seja, como imaginar a Elsa, de "Frozen", fazendo uma caminhada, por exemplo? Bom, o artista Samuel Chevé foi além e imaginou vários personagens da Disney como heróis da Marvel e da DC Comics.</p></div>
                        </div>
                    </li>
                    <li class="timeline-inverted">
                        <div class="timeline-image">
                            <h4>
                                Faça parte
                                <br />
                                Da nossa
                                <br />
                                História!
                            </h4>
                        </div>
                    </li>
                </ul>
            </div>
        </section>
        <!-- Equipe-->
        <section class="page-section bg-light" id="equipe">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Equipe</h2>
                    <h3 class="section-subheading text-muted">Responsável pelo site:</h3>
                </div>
                <div class="row">
                    <div class="col-lg-8 mx-auto text-center">
                        <div class="team-member" >
                            <img class="mx-auto rounded-circle" src="assets/img/team/1.jpg" alt="" />
                            <h4>Jean Henrique Marques Machado</h4>
                            <p class="text-muted">Web Desinger / Líder Projeto</p>
                            <a class="btn btn-dark btn-social mx-2" href="https://www.facebook.com/J3anH3nry/"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!"><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8 mx-auto text-center"><p class="large text-muted">Compromisso, trabalho em equipe e melhoria contínua são chaves para conquistar excelência em qualidade e satisfação dos clientes.</p></div>
                    </div>
                </div>
        </section>
        <!-- Clientes-->
        <div class="py-5">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6 my-3">
                        <a href="https://www.dccomics.com/"><img class="img-fluid d-block mx-auto" src="assets/img/logos/dcuniverse.png" alt="DC Universe" /></a>
                    </div>
                    <div class="col-md-3 col-sm-6 my-3">
                        <a><img class="img-fluid d-block mx-auto" src="assets/img/logos/herois.gif" alt="" /></a>
                    </div>
                    <div class="col-md-3 col-sm-6 my-3">
                        <a href="https://www.marvel.com/"><img class="img-fluid d-block mx-auto" src="assets/img/logos/marvel.png" alt="" /></a>
                    </div>
                    <div class="col-md-3 col-sm-6 my-3">
                        <a><img class="img-fluid d-block mx-auto" src="assets/img/logos/ironman.gif" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Contato-->
        <section class="page-section" id="contact">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Contate-nos</h2>
                    <h3 class="section-subheading text-muted">Mande um feedback para nossa equipe, agradecemos sua coloraboração.</h3>
                </div>
                <form id="contactForm" name="sentMessage" novalidate="novalidate">
                    <div class="row align-items-stretch mb-5">
                        <div class="col-md-6">
                            <div class="form-group">
                                <input class="form-control" id="name" type="text" placeholder="Seu Nome *" required="required" data-validation-required-message="Por favor digite seu nome." />
                                <p class="help-block text-danger"></p>
                            </div>
                            <div class="form-group">
                                <input class="form-control" id="email" type="email" placeholder="Seu E-mail *" required="required" data-validation-required-message="Por favor digite seu E-mail." />
                                <p class="help-block text-danger"></p>
                            </div>
                            <div class="form-group mb-md-0">
                                <input class="form-control" id="telefone" type="tel" placeholder="Seu Telefone *" required="required" data-validation-required-message="Por favor digite seu telefone." />
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group form-group-textarea mb-md-0">
                                <textarea class="form-control" id="mensagem" placeholder="Sua Mensagem *" required="required" data-validation-required-message="Por favor digite sua mensagem."></textarea>
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
                    </div>
                    <div class="text-center">
                        <div id="success"></div>
                        <button class="btn btn-primary btn-xl text-uppercase" id="sendMessageButton" type="submit">Enviar Mensagem</button>
                    </div>
                </form>
            </div>
        </section>
        
        <!-- Rodapé-->
        <footer class="footer py-4">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-4 text-lg-left">Copyright © Todos Direitos Reservados - SuperHerois 2020</div>
                    <div class="col-lg-4 my-3 my-lg-0">
                        <a class="btn btn-dark btn-social mx-2" href="https://twitter.com/marvel"><i class="fab fa-twitter"></i></a>
                        <a class="btn btn-dark btn-social mx-2" href="https://pt-br.facebook.com/MarvelBR/"><i class="fab fa-facebook-f"></i></a>
                    </div>
                    <div class="col-lg-4 text-lg-right">
                        <a class="mr-3" href="#!">Política de Privacidade</a>
                        <a href="#!">Termos de Uso</a>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Portfolio Modals-->
        <!-- Modal 1-->
        <div class="portfolio-modal modal fade" id="portfolioModal1" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="close-modal" data-dismiss="modal"><img src="assets/img/close-icon.svg" alt="Close modal" /></div>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="modal-body" style="color:green;">
                                    <!-- Project Details Go Here-->
                                    <h2 class="text-uppercase" style="color:green;">HULK</h2>
                                    <p class="item-intro text-muted">O INCRÍVEL HULK</p>
                                    <img class="img-fluid d-block mx-auto" src="assets/img/portfolio/01-full.jpg" alt="" />
                                    <p>O Dr. Robert Bruce Banner era um cientista do governo norte-americano, cujo trabalho era desenvolver uma poderosa bomba gama. Porém, durante um teste no deserto, o cientista percebeu que um jovem invadiu o local e encontra-se próximo demais da bomba que em breve será detonada. Banner dirige-se para o local e consegue lançar o jovem em uma trincheira, mas é colhido pela explosão. Embora sobreviva, logo ele descobre que momentos de tensão fazem com que ele se transforme em um poderoso monstro de pele esverdeada e dono de imensa força, que recebe o apelido de Hulk. O ser é caçado pelo exército e, mesmo quando enfrenta ameaças inimigas, tem suas ações mal-compreendidas e é considerado perigoso pelo governo norte-americano. Entre as inúmeras aventuras que viveu, foi um dos fundadores dos Vingadores, mas deixou a equipe pouco após a sua formação. Ao longo de sua história, a criatura alternou períodos de inteligência com períodos em que não tinha controle sobre suas ações. Atualmente, o Hulk age como um agente especial da SHIELD, a organização de defesa norte-americana.</p>
                                    <ul class="list-inline" style="color:green;">
                                        <li>Primeira Aparição: The Incredible Hulk 01 (maio de 1962)</li>
                                        <li>Criado por: Stan Lee e Jack Kirby</li>
                                    </ul>
                                    <button class="btn btn-primary" data-dismiss="modal" type="button">
                                        <i class="fas fa-times mr-1"></i>
                                        Fechar
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal 2-->
        <div class="portfolio-modal modal fade" id="portfolioModal2" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="close-modal" data-dismiss="modal"><img src="assets/img/close-icon.svg" alt="Close modal" /></div>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="modal-body" style="color:Red;">
                                    <!-- Project Details Go Here-->
                                    <h2 class="text-uppercase" style="color:Red;">Homem de Ferro</h2>
                                    <p class="item-intro text-muted">GÊNIO, BILIONÁRIO, PLAYBOY, FILANTROPO</p>
                                    <img class="img-fluid d-block mx-auto" src="assets/img/portfolio/02-full.jpg" alt="Iron Man" />
                                    <p>Tony Stark, um cientista e engenheiro de grande talento desde a adolescência, criou armas e tecnologia avançada que foi usada com objetivos militares por seu país. Playboy, industrial e milionário, quando adulto Stark sofreu um ferimento durante uma viagem ao Vietnã, que deixou um estilhaço de bomba alojada em seu peito . Feito prisioneiro por soldados inimigos, foi instruído por seus captores a construir poderosas e modernas armas para eles. Mas com a ajuda de um outro prisioneiro, também cientista, Stark construiu uma placa peitoral que impedia o estilhaço de alcançar seu coração e uma armadura capaz de voar e lançar projéteis variados, que usou para fugir do cativeiro – em versões mais recentes de sua história, sua origem foi atualizada e tem como cenário o Oriente Médio. De qualquer maneira, ao voltar para os Estados Unidos, Stark aperfeiçou a armadura e começou uma cruzada contra inimigos dos Estados Unidos, criminosos em geral e qualquer um que tentasse usar com propósitos excusos a tecnologia que criou. O Homem de Ferro foi um dos membros fundadores dos Vingadores e Tony Stark age como o principal patrocinador financeiro do grupo.</p>
                                    <ul class="list-inline">
                                        <li>Primeira aparição: Tales of Suspense 39 (março de 1963)</li>
                                        <li>Criado por: Stan Lee, Larry Lieber, Don Heck e Jack Kirby</li>
                                    </ul>
                                    <button class="btn btn-primary" data-dismiss="modal" type="button">
                                        <i class="fas fa-times mr-1"></i>
                                        Fechar
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal 3-->
        <div class="portfolio-modal modal fade" id="portfolioModal3" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="close-modal" data-dismiss="modal"><img src="assets/img/close-icon.svg" alt="Close modal" /></div>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="modal-body" style="color:DeepPink;">
                                    <!-- Project Details Go Here-->
                                    <h2 class="text-uppercase" style="color:DeepPink;">MULHER MARAVILHA</h2>
                                    <p class="item-intro text-muted">FILHA DE ZEUS</p>
                                    <img class="img-fluid d-block mx-auto" src="assets/img/portfolio/03-full.jpg" alt="" />
                                    <p>A Mulher-Maravilha tem uma das origens que mais sofreu alterações na história dos quadrinhos, devido às várias atualizações que a personagem sofreu ao longo das décadas. Inicialmente, Diana foi criada de maneira mágica, a partir de uma figura de argila, na misteriosa Ilha Paraíso – um reino escondido, mais tarde chamado de Themyscira –, por sua mãe, a Rainha Hipólita. Quando adulta, durante o período da Segunda Guerra Mundial, ela foi enviada ao mundo dos homens (no caso, os Estados Unidos), como embaixadora da paz e para lutar contra inimigos como os alemães e os japoneses. Durante diversos períodos e reformulações, ela usou a identidade secreta de Diana Prince, que teve várias encarnações: enfermeira, secretária, agente do Departamento de Defesa e até dona de uma butique de moda. Em sua última reformulação, ocorrida em 2011, a Mulher-Maravilha tornou-se uma semideusa, filha de Hipólita e do deus grego, Zeus. Com atitudes mais violentas, ela é considerada a nova encarnação do deus da guerra.</p>
                                    <ul class="list-inline" style="color:DeepPink;">
                                        <li>Primeira aparição: All Star Comics 8 (dezembro de 1941)</li>
                                        <li>Criada por: William Moulton Marston e Harry G. Peter</li>
                                    </ul>
                                    <button class="btn btn-primary" data-dismiss="modal" type="button">
                                        <i class="fas fa-times mr-1"></i>
                                        Fechar
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal 4-->
        <div class="portfolio-modal modal fade" id="portfolioModal4" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="close-modal" data-dismiss="modal"><img src="assets/img/close-icon.svg" alt="Close modal" /></div>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="modal-body">
                                    <!-- Project Details Go Here-->
                                    <h2 class="text-uppercase" style="color:DeepSkyBlue">THOR</h2>
                                    <p class="item-intro text-muted">DEUS DO TROVÃO</p>
                                    <img class="img-fluid d-block mx-auto" src="assets/img/portfolio/04-full.jpg" alt="" />
                                    <p style="color:DeepSkyBlue">Thor teve uma origem inusitada. O Dr. Donald Blake, um médico norte-americano que visitava a Noruega, encontra um velho cajado que, ao ser batido no chão, transforma-se no martelo mágina Mjolnir e torna o Dr. Blake no poderoso Thor, filho de Odin e Deus do Trovão. Após impedir uma invasão espacial e enfrentar outros perigos, o herói conhece Asgard, o reino dos deuses nórdicos, e descobre que na verdade não é um médico da Terra, mas sempre foi Thor: com dúvidas sobre a humildade de seu filho, o poderoso Odin tirou seus poderes, apagou sua memória e o enviou para viver em nosso planeta como um humano franzino e com uma perna aleijada. Só quando o deus desmemoriado aprendeu o significado da humilde e do amor aos seus semelhantes é que seu poderes retornaram a ele. </p>
                                    <ul class="list-inline" style="color:DeepSkyBlue">
                                        <li>Primeira aparição: Journey into Mystery 83 (agosto de 1962)</li>
                                        <li>Criado por: Stan Lee, Larry Lieber e Jack Kirby</li>
                                    </ul>
                                    <button class="btn btn-primary" data-dismiss="modal" type="button">
                                        <i class="fas fa-times mr-1"></i>
                                        Fechar
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal 5-->
        <div class="portfolio-modal modal fade" id="portfolioModal5" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="close-modal" data-dismiss="modal"><img src="assets/img/close-icon.svg" alt="Close modal" /></div>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="modal-body">
                                    <!-- Project Details Go Here-->
                                    <h2 class="text-uppercase" style="color:Red";>HOMEM ARANHA</h2>
                                    <p class="item-intro text-muted" style="color:Red";>ARANHA HUMANA</p>
                                    <img class="img-fluid d-block mx-auto" src="assets/img/portfolio/05-full.jpg" alt="" />
                                    <p style="color:Red";>Peter Parker era um adolescente órfão, tímido e franzino, dedicado aos estudos e com poucos amigos além de seus tios que o criaram, o casal Ben e May Parker. Mas a vida de Peter mudou quando visitou uma exposição de ciências e foi picado por uma aranha radioativa, fruto de um experimento realizado ali. Logo, Peter descobriu que adquiriu os poderes da aranha: a capacidade de se fixar a paredes e grande força física, além de um “sentido de aranha” que o avisa sobre situações perigosas. A princípio, Peter tentou ganhar dinheiro com seus poderes, ao participar de eventos de luta e aparecendo na televisão com um uniforme que criou. Porém, uma noite Peter não prendeu um ladrão após vê-lo cometer um crime, pois não considerava aquilo sua responsabilidade. Pouco tempo depois, o mesmo ladrão matou o tio de Peter e, após prendê-lo, o rapaz jurou combater o crime e defender os inocentes como o espetacular Homem-Aranha ao perceber que “grandes poderes trazem grandes responsablidades”.</p>
                                    <ul class="list-inline" style="color:Red";>
                                        <li>Primeira aparição: Amazing Fantasy 15 (agosto de 1962)</li>
                                        <li>Criado por: Stan Lee e Steve Ditko</li>
                                    </ul>
                                    <button class="btn btn-primary" data-dismiss="modal" type="button">
                                        <i class="fas fa-times mr-1"></i>
                                        Fechar
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal 6-->
        <div class="portfolio-modal modal fade" id="portfolioModal6" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content" style="color:Gray";>
                    <div class="close-modal" data-dismiss="modal"><img src="assets/img/close-icon.svg" alt="Close modal" /></div>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="modal-body">
                                    <!-- Project Details Go Here-->
                                    <h2 class="text-uppercase" style="color:Black";>BATMAN</h2>
                                    <p class="item-intro text-muted">HOMEM MORCEGO</p>
                                    <img class="img-fluid d-block mx-auto" src="assets/img/portfolio/06-full.jpg" alt="" />
                                    <p>Quando criança, o pequeno Bruce Wayne assistiu quando seus pais foram assassinados por um criminoso durante um assalto na cidade de Gotham City. O jovem decidiu que traria justiça a Gotham a qualquer preço e, assim que tornou-se adulto, viajou por todo o mundo para aprender técnicas de combate corporal e criminologia, com a intenção de tornar-se o maior detetive e combatente do crime de todo o mundo. Quando voltou a Gotham City, ainda indeciso sobre que rumo deveria seguir para realizar seu intento, Bruce presenciou um morcego que atravessou sua janela em uma fatídica noite. Decidiu que aquilo era um sinal: agora, ele se transformaria em um morcego, usando um uniforme que traria o medo e o terror ao coração dos criminosos. Com a fortuna de sua família e o auxílio de poucos mas fieis aliados, Batman usa os mais avançados recursos e equipamentos para enfrentar terrívelis inimigos em sua cidade e em todo o planeta.</p>
                                    <ul class="list-inline">
                                        <li>Primeira aparição: Detective Comics 27(maio de 1939)</li>
                                        <li>Criado por: Bob Kane e Bill Finger</li>
                                    </ul>
                                    <button class="btn btn-primary" data-dismiss="modal" type="button">
                                        <i class="fas fa-times mr-1"></i>
                                        Fechar
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Bootstrap core JS-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Third party plugin JS-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
        <!-- Contact form JS-->
        <script src="assets/mail/jqBootstrapValidation.js"></script>
        <script src="assets/mail/contact_me.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>
