<?php
define('HOST', 'localhost');
define('USUARIO', 'id14773151_jeanhenry');
define('SENHA', '6C8l11cl!@#$');
define('DB', 'id14773151_trabalhofinal');

$conexao = mysqli_connect(HOST, USUARIO, SENHA, DB) or die ('Não foi possível conectar');